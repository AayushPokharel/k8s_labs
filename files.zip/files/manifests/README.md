# Manifest workflow

The lab supports arbitrary student IDs without requiring students to edit YAML by hand.

The source manifests are `.yaml.tmpl` files that substitute `${LAB_NAMESPACE}`. The rendering script produces complete `.yaml` files with an explicit namespace under `rendered/<STUDENT>/`.

For example, `manifests/student01/` contains a fully rendered, valid YAML example for `STUDENT=student01`.

Students should use the render script rather than manually editing namespaces.
