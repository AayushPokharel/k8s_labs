#!/usr/bin/env bash
set -euo pipefail

: "${STUDENT:?Set STUDENT first, for example: export STUDENT=student01}"
: "${LAB_NAMESPACE:?Set LAB_NAMESPACE first, for example: export LAB_NAMESPACE=scalable-${STUDENT}}"

command -v envsubst >/dev/null 2>&1 || {
  echo "envsubst is required; Azure Cloud Shell normally includes it." >&2
  exit 1
}

OUT_DIR="rendered/${STUDENT}"
mkdir -p "$OUT_DIR"

for template in manifests/templates/*.yaml.tmpl; do
  name="$(basename "$template" .tmpl)"
  envsubst < "$template" > "$OUT_DIR/$name"
done

printf 'Rendered manifests for %s into %s\n' "$STUDENT" "$OUT_DIR"
